Feature: Login obligatorio - casos negativos (se cuentan aparte de los 15)

  Scenario Outline: <id> - Login rechazado: <caso>
    Given url baseUrl
    And path 'users', 'login'
    And request { email: '<email>', password: '<password>' }
    When method post
    * def ok = checkStatus('<id>', responseStatus)
    * def hayToken = response && response.token ? true : false
    * match hayToken == false

    Examples:
      | id     | caso                 | email             | password            |
      | LG-001 | contrasena incorrecta | #(testEmail)      | ClaveIncorrecta-123 |
      | LG-002 | email vacio          |                   | #(testPassword)     |
      | LG-003 | email sin arroba     | correo-sin-arroba | #(testPassword)     |
