Feature: Autenticacion - formas incorrectas de enviar el token

  Background:
    * url baseUrl
    * def auth = callonce read('classpath:common/login.feature')
    * def token = auth.token

  Scenario: CP-013 - Token en la URL y sin encabezado Authorization
    Given path 'contacts'
    And param token = token
    When method get
    Then status 401
    * match response == { error: 'Please authenticate.' }

  Scenario: CP-015 - Token valido en X-Auth-Token y sin Authorization
    Given path 'contacts'
    And header X-Auth-Token = token
    When method get
    Then status 401
    * match response == { error: 'Please authenticate.' }

  # CP-014 (dos encabezados Authorization) NO se automatiza en Karate:
  # Karate sobrescribe/combina encabezados repetidos. Se ejecuta solo en Postman.
