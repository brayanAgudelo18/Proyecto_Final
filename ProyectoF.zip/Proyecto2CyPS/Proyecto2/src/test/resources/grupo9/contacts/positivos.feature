Feature: Casos positivos sobre contactos

  Background:
    * url baseUrl
    * def auth = callonce read('classpath:common/login.feature')
    * def token = auth.token
    * def contactoCompleto =
    """
    {
      "firstName": "Ana",
      "lastName": "Prueba",
      "birthdate": "1990-01-15",
      "email": "ana.grupo9@ejemplo.com",
      "phone": "3001234567",
      "street1": "Calle 1 # 2-3",
      "street2": "Apto 4",
      "city": "Bogota",
      "stateProvince": "DC",
      "postalCode": "110111",
      "country": "Colombia"
    }
    """

  Scenario: CP-001 - Consultar contactos con el encabezado authorization en minusculas
    Given path 'contacts'
    And header authorization = 'Bearer ' + token
    When method get
    * def ok = checkStatus('CP-001', responseStatus)
    * match response == '#[]'

  Scenario: CP-002 - Consultar la lista dos veces seguidas y comparar
    Given path 'contacts'
    And header Authorization = 'Bearer ' + token
    When method get
    * def ok = checkStatus('CP-002', responseStatus)
    * match response == '#[]'
    * def primera = response
    Given path 'contacts'
    And header Authorization = 'Bearer ' + token
    When method get
    * match response == primera

  Scenario: CP-003 - Crear un contacto con todos los campos
    Given path 'contacts'
    And header Authorization = 'Bearer ' + token
    And request contactoCompleto
    When method post
    * def ok = checkStatus('CP-003', responseStatus)
    * match response contains contactoCompleto
    * match response ==
    """
    {
      "_id": "#string", "firstName": "#string", "lastName": "#string",
      "birthdate": "#string", "email": "#string", "phone": "#string",
      "street1": "#string", "street2": "#string", "city": "#string",
      "stateProvince": "#string", "postalCode": "#string", "country": "#string",
      "owner": "#string", "__v": "#number"
    }
    """

  Scenario: CP-004 - Consultar con el ETag recibido (If-None-Match)
    Given path 'contacts'
    And header Authorization = 'Bearer ' + token
    When method get
    Then status 200
    * def etag = responseHeaders['ETag'][0]
    * match etag == '#string'
    Given path 'contacts'
    And header Authorization = 'Bearer ' + token
    And header If-None-Match = etag
    When method get
    * def ok = checkStatus('CP-004', responseStatus)

  Scenario: CP-005 - Crear un contacto con correo que incluye +
    * def datos = karate.merge(contactoCompleto, { email: 'ana+qa@ejemplo.com' })
    Given path 'contacts'
    And header Authorization = 'Bearer ' + token
    And request datos
    When method post
    * def ok = checkStatus('CP-005', responseStatus)
    * match response.email == 'ana+qa@ejemplo.com'
