Feature: Casos negativos sobre contactos (usar SOLO cuentas y datos de prueba)

  Background:
    * url baseUrl
    * def auth = callonce read('classpath:common/login.feature')
    * def token = auth.token
    * def userId = auth.userId
    * def contactoCompleto =
    """
    {
      "firstName": "Ana",
      "lastName": "Prueba",
      "birthdate": "1990-01-15",
      "email": "ana.grupo9@ejemplo.com",
      "phone": "3001234567",
      "street1": "Calle 1 # 2-3",
      "street2": "Apto 4",
      "city": "Bogota",
      "stateProvince": "DC",
      "postalCode": "110111",
      "country": "Colombia"
    }
    """

  Scenario: CP-006 - Eliminar contactos sin indicar el ID
    Given path 'contacts'
    And header Authorization = 'Bearer ' + token
    When method get
    Then status 200
    * def antes = karate.sizeOf(response)
    Given path 'contacts'
    And header Authorization = 'Bearer ' + token
    When method delete
    * def ok = checkStatus('CP-006', responseStatus)
    Given path 'contacts'
    And header Authorization = 'Bearer ' + token
    When method get
    Then status 200
    * def despues = karate.sizeOf(response)
    * match despues == antes

  Scenario: CP-007 - Crear contacto con codigo script en el nombre
    * def datos = karate.merge(contactoCompleto, { firstName: '<script>alert(1)</script>', email: 'cp007@ejemplo.com' })
    Given path 'contacts'
    And header Authorization = 'Bearer ' + token
    And request datos
    When method post
    * def ok = checkStatus('CP-007', responseStatus)
    * print 'CP-007 respuesta:', responseStatus
    # Si lo guarda sin filtrar: oportunidad de mejora, no bug.

  Scenario: CP-008 - Consultar contactos con limit=-1
    Given path 'contacts'
    And header Authorization = 'Bearer ' + token
    And param limit = -1
    When method get
    * def ok = checkStatus('CP-008', responseStatus)

  Scenario: CP-009 - Consultar un contacto usando el ID del usuario
    Given path 'contacts', userId
    And header Authorization = 'Bearer ' + token
    When method get
    * def ok = checkStatus('CP-009', responseStatus)
    * def devolvioContacto = response && response.owner ? true : false
    * match devolvioContacto == false

  Scenario: CP-010 - Consultar un endpoint inexistente (/contactos)
    Given path 'contactos'
    And header Authorization = 'Bearer ' + token
    When method get
    * def ok = checkStatus('CP-010', responseStatus)
    * match response != '#[]'

  Scenario: CP-011 - Crear usando la ruta de un contacto existente
    # Precondicion: contacto propio de prueba
    * def datos = karate.merge(contactoCompleto, { email: 'cp011-pre@ejemplo.com' })
    Given path 'contacts'
    And header Authorization = 'Bearer ' + token
    And request datos
    When method post
    * if (responseStatus >= 300) karate.fail('Precondicion de CP-011 fallo: no se pudo crear el contacto')
    * def contactId = response._id
    Given path 'contacts'
    And header Authorization = 'Bearer ' + token
    When method get
    Then status 200
    * def antes = karate.sizeOf(response)
    * def otros = karate.merge(contactoCompleto, { email: 'cp011@ejemplo.com' })
    Given path 'contacts', contactId
    And header Authorization = 'Bearer ' + token
    And request otros
    When method post
    * def ok = checkStatus('CP-011', responseStatus)
    Given path 'contacts'
    And header Authorization = 'Bearer ' + token
    When method get
    Then status 200
    * match karate.sizeOf(response) == antes

  Scenario: CP-012 - Pedir la respuesta en XML
    Given path 'contacts'
    And header Authorization = 'Bearer ' + token
    And header Accept = 'application/xml'
    When method get
    * def ok = checkStatus('CP-012', responseStatus)
    * print 'CP-012 Content-Type:', responseHeaders['Content-Type']
