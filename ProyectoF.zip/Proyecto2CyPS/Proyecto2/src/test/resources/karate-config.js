function fn() {

    var config = {};

    // URL base de Contact List API
    config.baseUrl = 'https://thinking-tester-contact-list.herokuapp.com';

    // Credenciales externas (variables de entorno, nunca en el codigo)
    config.testEmail = java.lang.System.getenv('TEST_EMAIL');
    config.testPassword = java.lang.System.getenv('TEST_PASSWORD');

    // Codigos esperados fijados en la matriz tras la ejecucion exploratoria
    var expected = karate.read('classpath:common/expected.json');
    config.expected = expected;

    // Regla comun: nunca 5xx; si el criterio ya esta fijado, el codigo debe coincidir.
    config.checkStatus = function (id, status) {
        if (status >= 500) {
            karate.fail(id + ': el servicio respondio 5xx (' + status + ')');
        }
        var exp = expected[id];
        if (exp == null) {
            karate.log('AVISO ' + id + ': criterio exploratorio SIN fijar en common/expected.json (codigo recibido: ' + status + ')');
        } else if (exp != status) {
            karate.fail(id + ': codigo esperado ' + exp + ' pero se recibio ' + status);
        }
        return true;
    };
    // Heroku corta a los ~30 s; con 60 s Karate alcanza a ver el 503 en vez de un timeout
    karate.configure('readTimeout', 60000);
    
    return config;
}
