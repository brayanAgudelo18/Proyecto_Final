Feature: Login reutilizable (precondicion para obtener el token)

  Scenario: Obtener token
    Given url baseUrl
    And path 'users', 'login'
    And request { email: '#(testEmail)', password: '#(testPassword)' }
    When method post
    Then status 200
    * match response.token == '#string'
    * def token = response.token
    * def userId = response.user._id
