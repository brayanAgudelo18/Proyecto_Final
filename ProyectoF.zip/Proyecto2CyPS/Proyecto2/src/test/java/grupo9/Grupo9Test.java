package grupo9;

import io.karatelabs.junit6.Karate;
import org.junit.jupiter.api.DynamicNode;

class Grupo9Test {

    @Karate.Test
    Iterable<DynamicNode> testAuth() {
        return Karate.run("classpath:grupo9/auth");
    }

    @Karate.Test
    Iterable<DynamicNode> testContacts() {
        return Karate.run("classpath:grupo9/contacts");
    }
}
